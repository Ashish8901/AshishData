import React from 'react'
import {Route ,Switch} from "react-router-dom"

import Login from "./component/Login"
import Navbar from './component/Navbar'
import Homepage from './component/Homepage'
import Signup from './component/Signup'

const App = () => {
  return (
    <>
    <Navbar/>
    <Switch>

            <Route exact path="/" component={Homepage} />
            <Route path="/Login" component={Login} />
            <Route path="/Signup" component={Signup} />
            

     </Switch>
     

    </>
  )
}

export default App

